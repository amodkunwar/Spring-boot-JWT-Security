package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.JwtRequest;
import com.example.demo.model.JwtResponse;
import com.example.demo.service.CustomeUserDetailsService;
import com.example.demo.util.JwtUtil;

@RestController
public class JwtController {

	@Autowired
	private CustomeUserDetailsService customeUserDetailsService;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping(value = "/token")
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception {
		System.out.println(jwtRequest);
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(), jwtRequest.getPassword()));
		} catch (UsernameNotFoundException usernameNotFoundException) {
			usernameNotFoundException.printStackTrace();
			throw new Exception("Bad credentials");
		}
		catch (BadCredentialsException badCredentialsException) {
			badCredentialsException.printStackTrace();
			throw new Exception("Bad credentials");
		}

		// get user details :
		UserDetails userDetails = this.customeUserDetailsService.loadUserByUsername(jwtRequest.getUsername());
		String generateToken = this.jwtUtil.generateToken(userDetails);
		System.out.println("Token : " + generateToken);
		return ResponseEntity.ok(new JwtResponse(generateToken));
	}

}
